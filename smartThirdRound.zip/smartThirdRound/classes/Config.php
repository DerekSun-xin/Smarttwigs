<?php

class Config {
    public static $db = [
        "host" => "localhost",
        "user" => "root",
        "pass" => "",
        "database" => "smart"
    ];
}


