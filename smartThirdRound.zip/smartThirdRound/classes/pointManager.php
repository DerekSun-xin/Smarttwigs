<?php

class pointManager{
    private $command;
    private $db;

    public function __construct($command){
        $this->command =$command;
        $this->db = new Database();
    }

    public function run(){
        switch($this->command){
            case "Game":
                $this->Game();
                break;
            case "endGame":
                $this->endGame();
                break;
            case "playagain":
                $this->playagain();
            case "logout":
                $this->logout();
            case "login":
            default:
                $this->login();
                break;
        }
    }

    private function playagain(){
     unset($_SESSION["player1Score"]);
     unset($_SESSION["player2Score"]);
     unset($_SESSION["winner"]);
     header("Location?command=Game");
     include("templates/Game.php");
    }

    private function endGame(){
        include("templates/winner.php");
        $result = $this->db->query("select * from user order by wins desc, CumScore asc;");
        if($result===false){
            echo "fail to extract user wins";
        }else if(!empty($result)){
            echo "Name"." "."Wins"." "."Cumulative Score"."<br>";
            for($i=0;$i<count($result);$i++){
                echo $result[$i]["name"]." ".$result[$i]["wins"]." ".$result[$i]["CumScore"];
                echo "<br/>";
            }

        }else{
            echo "no results";

        }

    }


    private function Game(){
        if(isset($_POST["win1"]) || isset($_POST["win2"])){
            if(isset($_POST["win1"])){
                //update player1 score
                $data = $this->db->query("select * from user where name = ?;","s",$_SESSION["player1"]);
                if($data === false){
                    echo "get user1 score failed";
                }else if(!empty($data)){
                    $score = $data[0]["scores"];
                    $score = $score +1;
                    $_SESSION["player1Score"] = $score;
                }else{
                    //empty
                    echo "cannot find the user1";
                }
                $this->db->query("update user set scores=? where name = ?;","is",$score,$_SESSION["player1"]);



                //check winning
                if($_SESSION["player1Score"]>=10 && $_SESSION["player2Score"]>=10){
                    //they need two points to win
                    if($_SESSION["player1Score"]-$_SESSION["player2Score"]==2){
                        $_SESSION["winner"] = $_SESSION["player1"];
                        $data = $this->db->query("select * from user where name = ?;","s",$_SESSION["player1"]);
                        $wins = $data[0]["wins"];
                        $CumScore = $data[0]["CumScore"];
                        $wins=$wins+1;
                        $this->db->query("update user set wins=? where name = ?;","is",$wins,$_SESSION["player1"]);
                        $CumScore=$CumScore+$score;
                        $this->db->query("update user set CumScore=? where name = ?;","is",$CumScore,$_SESSION["player1"]);

                        $this->db->query("update user set scores=? where name = ?;","is",0,$_SESSION["player1"]);
                        unset($_SESSION["player1Score"]);
                        $this->db->query("update user set scores=? where name = ?;","is",0,$_SESSION["player2"]);
                        unset($_SESSION["player2Score"]);
                        header("Location:?command=endGame");
                    }else if($_SESSION["player2Score"]-$_SESSION["player1Score"]==2){
                        $_SESSION["winner"] = $_SESSION["player2"];
                        $data = $this->db->query("select * from user where name = ?;","s",$_SESSION["player2"]);
                        $wins = $data[0]["wins"];
                        $wins=$wins+1;
                        $CumScore = $data[0]["CumScore"];
                        $CumScore= $CumScore+$score;
                        $this->db->query("update user set wins=? where name = ?;","is",$wins,$_SESSION["player2"]);
                        $this->db->query("update user set CumScore=? where name = ?;","is",$CumScore,$_SESSION["player2"]);
                        $this->db->query("update user set scores=? where name = ?;","is",0,$_SESSION["player1"]);
                        unset($_SESSION["player1Score"]);
                        $this->db->query("update user set scores=? where name = ?;","is",0,$_SESSION["player2"]);
                        unset($_SESSION["player2Score"]);
                        header("Location:?command=endGame");
                    }

                }else if($score == 11){
                    $_SESSION["winner"] = $_SESSION["player1"];
                    $data = $this->db->query("select * from user where name = ?;","s",$_SESSION["player1"]);
                    $wins = $data[0]["wins"];
                    $CumScore = $data[0]["CumScore"];
                    $wins=$wins+1;
                    $this->db->query("update user set wins=? where name = ?;","is",$wins,$_SESSION["player1"]);
                    $CumScore=$CumScore+$score;
                    $this->db->query("update user set CumScore=? where name = ?;","is",$CumScore,$_SESSION["player1"]);

                    $this->db->query("update user set scores=? where name = ?;","is",0,$_SESSION["player1"]);
                    unset($_SESSION["player1Score"]);
                    $this->db->query("update user set scores=? where name = ?;","is",0,$_SESSION["player2"]);
                    unset($_SESSION["player2Score"]);
                    header("Location:?command=endGame");
                }
                include("templates/Game.php");
                return;
            }else{
                //update player2 score
                $data = $this->db->query("select * from user where name = ?;","s",$_SESSION["player2"]);
                if($data === false){
                    echo "get user2 score failed";
                }else if(!empty($data)){
                    $score = $data[0]["scores"];
                    $score = $score +1;
                    $_SESSION["player2Score"] = $score;
                }else{
                    //empty
                    echo "cannot find the user2";
                }
                $this->db->query("update user set scores=? where name = ?;","is",$score,$_SESSION["player2"]);


                if($_SESSION["player1Score"]>=10 && $_SESSION["player2Score"]>=10){
                    //they need two points to win
                    if($_SESSION["player1Score"]-$_SESSION["player2Score"]==2){
                        $_SESSION["winner"] = $_SESSION["player1"];
                        $data = $this->db->query("select * from user where name = ?;","s",$_SESSION["player1"]);
                        $wins = $data[0]["wins"];
                        $CumScore = $data[0]["CumScore"];
                        $wins=$wins+1;
                        $this->db->query("update user set wins=? where name = ?;","is",$wins,$_SESSION["player1"]);
                        $CumScore=$CumScore+$score;
                        $this->db->query("update user set CumScore=? where name = ?;","is",$CumScore,$_SESSION["player1"]);

                        $this->db->query("update user set scores=? where name = ?;","is",0,$_SESSION["player1"]);
                        unset($_SESSION["player1Score"]);
                        $this->db->query("update user set scores=? where name = ?;","is",0,$_SESSION["player2"]);
                        unset($_SESSION["player2Score"]);
                        header("Location:?command=endGame");
                    }else if($_SESSION["player2Score"]-$_SESSION["player1Score"]==2){
                        $_SESSION["winner"] = $_SESSION["player2"];
                        $data = $this->db->query("select * from user where name = ?;","s",$_SESSION["player2"]);
                        $wins = $data[0]["wins"];
                        $wins=$wins+1;
                        $CumScore = $data[0]["CumScore"];
                        $CumScore= $CumScore+$score;
                        $this->db->query("update user set wins=? where name = ?;","is",$wins,$_SESSION["player2"]);
                        $this->db->query("update user set CumScore=? where name = ?;","is",$CumScore,$_SESSION["player2"]);
                        $this->db->query("update user set scores=? where name = ?;","is",0,$_SESSION["player1"]);
                        unset($_SESSION["player1Score"]);
                        $this->db->query("update user set scores=? where name = ?;","is",0,$_SESSION["player2"]);
                        unset($_SESSION["player2Score"]);
                        header("Location:?command=endGame");
                    }

                }else if($score == 11){
                    $_SESSION["winner"] = $_SESSION["player2"];
                    $data = $this->db->query("select * from user where name = ?;","s",$_SESSION["player2"]);
                    $wins = $data[0]["wins"];
                    $wins=$wins+1;
                    $CumScore = $data[0]["CumScore"];
                    $CumScore= $CumScore+$score;
                    $this->db->query("update user set wins=? where name = ?;","is",$wins,$_SESSION["player2"]);
                    $this->db->query("update user set CumScore=? where name = ?;","is",$CumScore,$_SESSION["player2"]);
                    $this->db->query("update user set scores=? where name = ?;","is",0,$_SESSION["player1"]);
                    unset($_SESSION["player1Score"]);
                    $this->db->query("update user set scores=? where name = ?;","is",0,$_SESSION["player2"]);
                    unset($_SESSION["player2Score"]);
                    header("Location:?command=endGame");
                }
                include("templates/Game.php");
                return;
            }
        }
        include("templates/Game.php");
    }

    private function logout(){
        session_destroy();
    }

    private function login(){
        if(isset($_POST["player1"]) && isset($_POST["player2"])){
            $success1 =0;
            $success2 =0;
            $data1 = $this->db->query("select * from user where name = ?;","s",$_POST["player1"]);
            $data2 = $this->db->query("select * from user where name = ?;","s",$_POST["player2"]);
            if($data1 === false){
                echo '<script>alert("Error checking the player1")</script>';
            }else if(!empty($data1)){
                //User exists in the DB
                $success1 = 1;
            }else{
                //insert the user into DB
                $insert = $this->db->query("insert into user (name,wins,scores,CumScore) values(?,?,?,?);","siii",
                    $_POST["player1"],0,0,0);
                if($insert===false){
                    echo  '<script>alert("Insert player1 failed")</script>';
                }else{
                    //insertion succeeds do nothing
                    $success1 = 1;
                }
            }

            if($data2 ===false){
                echo '<script>alert("Error checking the player2")</script>';
            }else if(!empty($data2)){
                //User not exists in the DB
                $success2 = 1;
            }else{
                $insert = $this->db->query("insert into user (name,wins,scores,CumScore) values(?,?,?,?);","siii",
                    $_POST["player2"],0,0,0);
                if($insert===false){
                    echo  '<script>alert("Insert player2 failed")</script>';
                }else{
                    //insertion succeeds do nothing
                    $success2 = 1;
                }
            }

            //Set session variable
            $_SESSION["player1"] = $_POST["player1"];
            $_SESSION["player2"] = $_POST["player2"];
            $_SESSION["player1Score"] = 0;
            $_SESSION["player2Score"] = 0;

            //Set the server for this session
            $_SESSION["server"] = $_POST["player1"]; //default
            if(isset($_POST["server2"]) && !isset($_POST["server1"])){
                $_SESSION["server"] = $_POST["player2"];
            }

            if($success1==1 && $success2==1){
                header("Location: ?command=Game");
                return ;
            }
        }
        include("templates/login.php");
    }


}
