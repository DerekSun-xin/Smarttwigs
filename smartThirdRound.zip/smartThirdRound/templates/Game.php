<!DOCTYPE html>
<html>
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    <title>Game Page</title>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="login.php">History</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item active">
                <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#"><?=$_SESSION["player1"].",".$_SESSION["player2"]?></a>
            </li>
                <a class="nav-link" href="?command=logout">Log Out</a>
            </li>
        </ul>
    </div>
</nav>
<br>
<div>
    <h3>Game Stat</h3>
    <p><?=$_SESSION["player1"]." Score:".$_SESSION["player1Score"]?></p>
    <p><?=$_SESSION["player2"]." Score:".$_SESSION["player2Score"]?></p>
</div>
<br>
<form action="?command=Game" method="post">
    <h3 style="text-align: center;">Who wins this round?</h3>
    <div style="text-align: center;" class="mb-3">
        <input type="radio" id="win1" name="win1" value="<?=$_SESSION["player1"]?>">
        <label for="win1"><?=$_SESSION["player1"]?></label>

        <input type="radio" id="win2" name="win2" value="<?=$_SESSION["player2"] ?>">
        <label for="win2"><?=$_SESSION["player2"]?></label>
    </div>
    <div class="text-center">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</form>
<div class="collapse navbar-collapse" id="navbarNav">
        <li class="nav-item">
            <a class="nav-link" href="?command=logout">Exit the Game</a>
        </li>
    </ul>
</div>
</body>
</html>