<html>
<body>
<h2 style="text-align: center">Welcome to the Leader Board!</h2>
<h3 style="text-align: center">Congratulations, the winner is <?=$_SESSION["winner"]?></h3>
<br>
<div class="text-center">
    <!--<a href="?command=playagain" class="btn btn-primary">Play Again</a> &nbsp-->
    <a href="?command=logout" class="btn btn-danger">Exit Game</a>
</div>
</body>
</html>