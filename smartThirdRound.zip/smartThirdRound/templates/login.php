<!DOCTYPE html>
<html>
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

</head>

<body>
<div class="container" style="margin-top: 15px;">
    <div class="row col-xs-8">
        <h1>Ping Pong Game: Get Started</h1>
        <p>Welcome to the game! To get started, please enter your name, your opponent's name, and who to serve first. </p>
    </div>
    <div class="row justify-content-center">
        <div class="col-4">
            <form action="?command=login" method="post">
                <div class="mb-3">
                    <label for="name" class="form-label">Player1</label>
                    <input type="text" class="form-control" id="player1" name="player1"/>
                </div>
                <div class="mb-3">
                    <label for="name" class="form-label">Player2</label>
                    <input type="text" class="form-control" id="player2" name="player2"/>
                </div>
                <div class="mb-3">
                    <p>Who Serves first?</p>
                    <input type="radio" id="name" name="server1" value="player1">
                    <label for="player1">Player1</label>
                    <input type="radio" id="name" name="server2" value="player2">
                    <label for="player2">Player2</label>
                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-primary">Start</button>
                </div>
            </form>
        </div>
    </div>
</div>
</body>
</html>

