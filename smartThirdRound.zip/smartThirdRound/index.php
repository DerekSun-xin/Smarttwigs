<?php
session_start();

spl_autoload_register(function($classname){
    include "classes/$classname.php";
});

$command = "login";
if(isset($_GET["command"])){
    $command = $_GET["command"];
}

$pointManager = new pointManager($command);
$pointManager->run();


