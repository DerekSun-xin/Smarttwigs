<?php

spl_autoload_register(function($classname) {
    include "classes/$classname.php";
});

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$db = new mysqli(Config::$db["host"],
    Config::$db["user"],Config::$db["pass"],
    Config::$db["database"]);

//Create table in the database next
$db->query("create table user (
    id int not null auto_increment,
    name text not null,
    wins int not null,
    scores int not null,
    CumScore int not null,
    primary key (id)
);");








